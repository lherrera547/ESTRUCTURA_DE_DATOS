import tallerconcolores.Auto;

public class TallerConColores {
    public static void main(String[] args) {
        Auto auto1 = new Auto("Toyota", "Fortuner", 2018, "Camioneta");
        Auto auto2 = new Auto("Ford", "Explorer", 2020, "Camioneta");
        Auto auto3 = new Auto("Chevrolet", "Spark", 2015, "Compacto");
        
        auto1.imprimirInformacion();
        auto2.imprimirInformacion();
        auto3.imprimirInformacion();
    }
}