package tallerconcolores;

public class Auto {
    private String marca;
    private String modelo;
    private int añoFabricacion;
    private String tipo; // Por ejemplo, sedan, camioneta, etc.

    public Auto(String marca, String modelo, int añoFabricacion, String tipo) {
        this.marca = marca;
        this.modelo = modelo;
        this.añoFabricacion = añoFabricacion;
        this.tipo = tipo;
    }
    
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAñoFabricacion() {
        return añoFabricacion;
    }

    public void setAñoFabricacion(int añoFabricacion) {
        this.añoFabricacion = añoFabricacion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void imprimirInformacion() {
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Año de fabricación: " + añoFabricacion);
        System.out.println("Tipo: " + tipo);
    }

    public boolean esClasico() {
        // Por ejemplo, si el auto tiene más de 25 años de antigüedad
        int añoActual = 2024; // Asumiendo que estamos en el año 2024
        return añoActual - añoFabricacion > 25;
    }
}
