import java.util.Scanner;

class Horario {
    private String nombre;
    private int horasLibres;

    public Horario(String nombre, int horasLibres) {
        this.nombre = nombre;
        this.horasLibres = horasLibres;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getHorasLibres() {
        return horasLibres;
    }

    public void setHorasLibres(int horasLibres) {
        this.horasLibres = horasLibres;
    }

    public void mostrarInfo() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Horas libres: " + horasLibres);
    }
}

public class GestionHorasLibres {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Horario[] horarios = new Horario[5]; // Supongamos que gestionaremos 5 horarios

        // Ingreso de información
        for (int i = 0; i < horarios.length; i++) {
            System.out.println("Ingrese el nombre del horario " + (i+1) + ":");
            String nombre = scanner.nextLine();
            System.out.println("Ingrese las horas libres para " + nombre + ":");
            int horasLibres = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer del scanner
            horarios[i] = new Horario(nombre, horasLibres);
        }

        // Menú de opciones
        int opcion;
        do {
            System.out.println("\n--- MENÚ ---");
            System.out.println("1. Mostrar información de todos los horarios");
            System.out.println("2. Salir");
            System.out.print("Ingrese una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer del scanner

            switch (opcion) {
                case 1:
                    System.out.println("\nInformación de los horarios:");
                    for (Horario horario : horarios) {
                        horario.mostrarInfo();
                        System.out.println("-----------------------");
                    }
                    break;
                case 2:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, ingrese una opción válida.");
            }
        } while (opcion != 2);
    }
}
